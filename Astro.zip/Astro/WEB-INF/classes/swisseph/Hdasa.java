package swisseph;
import java.util.Date; 
import java.util.Calendar;
import java.util.TimeZone; 
import java.util.GregorianCalendar;
import java.text.DateFormat; 
import java.io.*;
import java.lang.*; 
import java.io.File;
import java.text.*;
import java.util.*;
import swisseph.*;

public class Hdasa 
{
  public  String PBdate,PBtime,Ptdate,PLongLat,PLat, Pasign;
  public  int birthdint,bdint,bmint,byint,anytime,anytd,anytm,anyty,tdint,tmint,tyint,Pzdays,Piteration=0;

     public int[] Hdasa1(String JBdate, String JBtime, String Jtdate, String JLongLat, String JLat, int Jzdays, String Jasign, int Jiteration) 
     { 
	int[] lret=new int[16];
	PBdate=JBdate;
	PBtime=JBtime;
//	PLongLat=JLongLat;
//	PLat=JLat;
	Ptdate=Jtdate;
	Pzdays=Jzdays;
	Pasign=Jasign;
	Piteration=Jiteration;
//	String PBdate=PxBdate.substring(0,2)+PxBdate.substring(3,5)+PxBdate.substring(6,10);
	birthdint=Integer.parseInt(PBdate);
	bdint = (birthdint/1000000);  
	bmint = ((birthdint/10000)%100);  
	byint = (birthdint%10000);
	anytime=Integer.parseInt(Ptdate);
	    tdint=(anytime/1000000);
	    tmint=((anytime/10000)%100); 
	    tyint =(anytime%10000);

	if (Piteration>0) { //only if 'Casting' its set to 1 else for transactions like D+ D- its 0
	anytd=bdint; anytm=bmint; anyty=byint;
        }
   	else {	anytd=tdint; anytm=tmint; anyty=tyint;
   	}
	 double ival=0.0; double ival2=0.0;
	 double moon3deg=0.0; double moon3deg2=0.0;
	
  int dc=1; 
  int dg,dgonedays=0;
  int xxtd=0; int xxtm=0; int xxty=0; int ldays=0;
  xxtd=anytd;  xxtm=anytm;  xxty=anyty; 
  double percgone = 0.0; int dldd,dldm,dldy=0;
  int dasaleftdays,ddd=0;
  int dcinterm=0;
  StringBuffer dasaname= new StringBuffer("Ketu Venus SUN Moon Mars Rahu JuptrSatrnMercy");
  StringBuffer darray= new StringBuffer("072006100718161917");
  String asign="A";

    SwissEph sw=new SwissEph();
    sw.swe_set_sid_mode(1,0.0,0.0);
    int tc_time =0;
    int swyyyy = 0; int swmm =0; int swdd =0; double hlat; double hlong;

    swyyyy=anyty; swmm=anytm; swdd=anytd; 
    tc_time=Integer.parseInt(PBtime);
    double swhh = (double)(tc_time/100);
    double swmin = (double)(tc_time%100);
	hlong=Double.parseDouble(JLongLat);
	hlat=Double.parseDouble(JLat);
//    int ihsys =(int)'P';
    int ihsys =(int)'V';
    int hflags = SweConst.SEFLG_SIDEREAL | SweConst.SEFLG_SPEED | SweConst.SEFLG_TOPOCTR;
    StringBuffer sbErr=new StringBuffer();
    double[] hres=new double[6];
    sw.swe_set_topo(hlong,hlat,0);
	
// ADJUSTMENT OF -0.5 deg for MOON is done 2 places below If and ELSE

	if (Piteration>0) 
	{ 	swyyyy=byint; swmm=bmint; swdd=bdint; 
		SweDate sd1=new SweDate(swyyyy,swmm,swdd,swhh+swmin/60.);
		int iflgret_Moon2 = sw.swe_calc_ut(sd1.getJulDay(), 1, hflags,hres,sbErr);
      if(hres[0]==0.7000000){ival2=359.99;}
	  else if(hres[0]<0.700000){ival2=hres[0]+360.000-0.700000;}
	  else {ival2=hres[0]-0.700000;}
		ival=(1000000*ival2); //ival=(1000000*hres[0]);
		moon3deg=ival/1000000.0;
//	System.out.println("hres1-"+hres[0]+"Ival1-"+ival+"m3deg1"+moon3deg);
// this line changed below on 21 feb 22			dcinterm=(int)(Math.round(moon3deg/13.333));
		 dcinterm=(int)Math.ceil(moon3deg/13.333);//(roundup)
		if (dcinterm >9) {dc=(dcinterm%9);}//remainder
		else {dc=dcinterm;}
		if (dc==0) {dc=9;}
		dg =Integer.parseInt(darray.substring( ((dc*2)-2),(dc*2) ));
		percgone= (((moon3deg%13.333333)*dg*360)/13.333333);
	}
	else 
	{	swyyyy=byint; swmm=bmint; swdd=bdint; 
		SweDate sd1=new SweDate(swyyyy,swmm,swdd,swhh+swmin/60.);
		int iflgret_Moon2 = sw.swe_calc_ut(sd1.getJulDay(), 1, hflags,hres,sbErr);
      if(hres[0]==0.7000000){ival2=359.99;}
	  else if(hres[0]<0.700000){ival2=hres[0]+360.000-0.700000;}
	  else {ival2=hres[0]-0.700000;}
		ival=(1000000*ival2); //ival=(1000000*hres[0]);
		moon3deg2=ival/1000000.0;
//	System.out.println("hres1-"+hres[0]+"Ival1-"+ival+"m3deg2"+moon3deg);
// this line changed below on 21 feb 22		dcinterm=(int)(Math.round(moon3deg2/13.333));
	   dcinterm=(int)Math.ceil(moon3deg2/13.333);//(roundup)		
		if (dcinterm >9) {dc=(dcinterm%9);}//remainder
		else {dc=dcinterm;}
		if (dc==0) {dc=9;}
		dg =Integer.parseInt(darray.substring( ((dc*2)-2),(dc*2) ));
		percgone= (((moon3deg2%13.333333)*dg*360)/13.333333);
	}
// If Pzdays and Pasign is being used to Recalc dasadaysleft, only below, then how dc is being decided Above?
	dgonedays =(int)(percgone);
	dasaleftdays =((dg*360)-dgonedays); 
        ddd = dasaleftdays;
        if (String.valueOf(Pasign).equals(String.valueOf(asign))) // it was earlier as equals ("A")
           { ddd = ddd+Pzdays; } 
		else {ddd=ddd-Pzdays; }
// System.out.println("asign-"+asign+" Pasign-"+Pasign+" Pzdays-"+Pzdays);
        dldy = (int)(ddd/360); dldm = (int)((ddd%360)/30); dldd = (int)((ddd%360)%30);
    	lret[0]=dldd; lret[1]=dldm; lret[2]=dldy;  lret[15]=dc;

// do check if this AnyTM is for ist or gmt ?
// is following subtracting DoB date from Now date ? and result in form of number of Days?
	  if(anytd<bdint) {anytd=anytd+30; anytm--;}
	  if(anytm<bmint) {anytm=anytm+12; anyty--;}
      ldays=(int)((anytd-bdint)+((anytm-bmint)*30)+((anyty-byint)*360)+dgonedays);
      if (String.valueOf(Pasign).equals(String.valueOf(asign))) 
           { ldays = ldays-Pzdays;} 
  	  else {ldays=ldays+Pzdays;}


//----
int dba=dc; int db=dc; int dasa=dc; 
double dldays = 0.0; double dbldays = 0.0;  double  dbaldays = 0.0;
double checkdays=0.0; double[] lcheck=new double[10]; int[] ltot=new int[10];
    dcount:
	for (int j=0; j<9; j++) 
    {  checkdays = (Integer.parseInt(darray.substring(((dasa*2)-2),(dasa*2)))*360);
	   if (ldays > checkdays ) 
        {  ldays=ldays-(int)checkdays;
              dasa++;db++;dba++;
              if (dasa>9) {dasa=1;db=1;dba=1;}
              continue dcount;
                   
        } else {j=9; dldays = checkdays - ldays;
                }
		dbcount:
		for (int k=0; k<9; k++)
		{     checkdays=(  Integer.parseInt(darray.substring( ((db*2)-2)  ,(db*2  ) )) 
                        *Integer.parseInt(darray.substring( ((dasa*2)-2),(dasa*2) )) *3 );
                        
			if (ldays > checkdays )
            {  
              ldays=ldays - (int)checkdays; 
              db++;dba++;
              if (db>9){db=1;dba=1;}
              continue dbcount;
            } else {k=9;  dbldays=checkdays -ldays;}
       
			dbacount:
			for (int l=0; l<9; l++) 
			{ checkdays = ((Integer.parseInt(darray.substring( ((dba*2)-2),(dba*2  ) ))
                      *Integer.parseInt(darray.substring( ((db*2)-2),(db*2) ))
                      *Integer.parseInt(darray.substring( ((dasa*2)-2),(dasa*2) ) ) )
                        /40.0 );
              if (ldays > checkdays ) 
			  {	  ldays=ldays-(int)checkdays; ltot[dba]=ldays; lcheck[dba]=checkdays;
				  dba++;
				  if (dba>9){dba=1;}
				  continue dbacount;
			  } else {dbaldays = checkdays - ldays; 
                   j=9; k=9;l=9;   break;} 
          
			} // end dbacount
		} //end dbcount 
    }//end dcount

int jdd  =0; int jdm  =0; int jdy  =0; 
int jjdd =0; int jjdm =0; int jjdy =0; 
int kdd  =0; int kdm  =0; int kdy  =0; 
int kkdd =0; int kkdm =0; int kkdy =0; 
int ldd  =0; int ldm  =0; int ldy  =0; 
int lldd =0; int lldm =0; int lldy =0; 
//  GregorianCalendar cal = new GregorianCalendar();
// DayCountBasis dcb = DayCountBasis.BasisNASD;
//  cal.set(xxty,xxtm-1,xxtd); cal.add(Calendar.DATE,+(int)dldays);

int mcarry,ycarry=0;
jdy=(int)(dldays/360); jdm=(int)((dldays%360)/30); jdd=(int)((dldays%360)%30);
if (((jdd+xxtd)%30)==0){jjdd=jdd+xxtd; mcarry=0;} else {jjdd=((jdd+xxtd)%30); mcarry=((jdd+xxtd)/30);}
if ( ((int)(mcarry+xxtm+jdm)%12) ==0) {jjdm= (mcarry+xxtm+jdm);ycarry=0;}
else{ jjdm=( (int)(mcarry+xxtm+jdm)%12 );ycarry=( (int)(mcarry+xxtm+jdm)/12 );}
jjdy=(ycarry+xxty+jdy);

kdy=(int)(dbldays/360); kdm=(int)((dbldays%360)/30); kdd=(int)((dbldays%360)%30);
if (((kdd+xxtd)%30)==0){kkdd=kdd+xxtd; mcarry=0;} else {kkdd=((kdd+xxtd)%30); mcarry=((kdd+xxtd)/30);}
if ( ((int)(mcarry+xxtm+kdm)%12) ==0) {kkdm= (mcarry+xxtm+kdm);ycarry=0;}
else{ kkdm=( (int)(mcarry+xxtm+kdm)%12 );ycarry=( (int)(mcarry+xxtm+kdm)/12 );}
kkdy=(ycarry+xxty+kdy);

ldy=(int)(dbaldays/360); ldm=(int)((dbaldays%360)/30); ldd=(int)((dbaldays%360)%30);
if (((ldd+xxtd)%30)==0){lldd=ldd+xxtd; mcarry=0;} else {lldd=((ldd+xxtd)%30); mcarry=((ldd+xxtd)/30);}
if ( ((int)(mcarry+xxtm+ldm)%12) ==0) {lldm= (mcarry+xxtm+ldm);ycarry=0;}
else{ lldm=( (int)(mcarry+xxtm+ldm)%12 );ycarry=( (int)(mcarry+xxtm+ldm)/12 );}
lldy=(ycarry+xxty+ldy);

//------------------
lret[3]=jjdd; lret[4]=jjdm; lret[5]=jjdy; 
lret[6]=kkdd; lret[7]=kkdm; lret[8]=kkdy; 
lret[9]=lldd; lret[10]=lldm; lret[11]=lldy; 
lret[12]=dasa; lret[13]=db; lret[14]=dba;

return(lret);

}

public static void  main(String args[])
{  
    Hdasa fjsp = new Hdasa();

} //closes main

}
