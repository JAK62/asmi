package swisseph;
import swisseph.DblObj;
import java.util.Date; 
import java.util.Calendar;
import java.util.TimeZone; 
import java.util.GregorianCalendar;
import java.text.DateFormat; 
import java.io.*;
import java.lang.*; 
import java.io.File;
import java.text.*;
import java.util.*;
import swisseph.*;

public class Hc2 
{
    String PxBdate,PBtime,PLongLat, PLat;
    double ayandouble=0.0;
    int ayanint=0;
  public  int birthdint,bdint,bmint,byint,anytime,anytd,anytm,anyty,tdint,tmint,tyint=0;
    
     public double[] Hd2(String JBdate, String JBtime, String JLongLat, String JLat, int Ay, double Ayval) 
     { 
	PxBdate=JBdate;
	String PBdate=PxBdate.substring(0,2)+PxBdate.substring(3,5)+PxBdate.substring(6,10);
	PBtime=JBtime;
                ayanint=Ay;
                ayandouble=Ayval;
//	PLongLat=JLongLat;
//	PLat=JLat;

	 double ival=0.0;
	 double moon3deg=0.0;
	 double hressatlat=0.0;
	 double hressatspeed=0.0;
	 double hresmarlat=0.0;
	 double hresmarspeed=0.0;
	 double hresjuplat=0.0;
	 double hresjupspeed=0.0;
//	double[] hret=new double[28]; changed, increased from 28 to 40 for Hcusp info of 12 houses
	double[] hret=new double[41];

	birthdint=Integer.parseInt(PBdate);
	bdint = (birthdint/1000000);  
	bmint = ((birthdint/10000)%100);  
	byint = (birthdint%10000);
	anytd=bdint; anytm=bmint; anyty=byint;

// begin swiss

	  int hhlagna=0; int hlagna=0; // new line for jsp
	  int dasaleftdays,ddd=0;
    SwissEph sw=new SwissEph();
//    sw.swe_set_sid_mode(1,0.0,0.0); //moved  below for ayanamsa
    int tc_time =0;
    int swyyyy = 0; int swmm =0; int swdd =0; double hlat; double hlong;

    swyyyy=anyty; swmm=anytm; swdd=anytd; 
    tc_time=Integer.parseInt(PBtime);
    double swhh = (double)(tc_time/100);
    double swmin = (double)(tc_time%100);
    SweDate sd=new SweDate(swyyyy,swmm,swdd,swhh+swmin/60.);
//    int idays=Integer.parseInt(PLongLat);
//    int idays2=Integer.parseInt(PLat);
//    hlong=(idays/100.0);
//    hlat=(idays2/100.0);
	hlong=Double.parseDouble(JLongLat);
	hlat=Double.parseDouble(JLat);
//    int ihsys =(int)'P'; This flag for KP Ascendant  set to Placidius ; for Bhava madhya in Hc1 set V to Vehlov for Equalhouse in Hc1
    int ihsys =(int)'P';
    int hflags = SweConst.SEFLG_SIDEREAL | SweConst.SEFLG_SPEED | SweConst.SEFLG_TOPOCTR;
//   adding one flag for Surya Sidhanta !!
//    int hflags = SweConst.SEFLG_SIDEREAL | SweConst.SEFLG_SPEED | SweConst.SEFLG_TOPOCTR | SweConst.SEFLG_TRUEPOS;
    double[] hcusp =new double[13];
    double[] hascmc=new double[10];
    double[] hres=new double[6];
    StringBuffer sbErr=new StringBuffer();
//-------------------------------------------------   A Y A N A M S A ----------------------------------
 sw.swe_set_sid_mode(1,0.0,0.0);
//System.out.println(sw.swe_get_ayanamsa(sd.getJulDay()) );
    if (ayandouble==0.0) {  sw.swe_set_sid_mode(ayanint,0.0,0.0); }//moved  from above for ayanamsa
    else {  sw.swe_set_sid_mode(255,sd.getJulDay(),ayandouble); }
/*
    if (ayandouble==0.0) {  sw.swe_set_sid_mode(1,0.0,0.0); }//moved  from above for ayanamsa
    else {  sw.swe_set_sid_mode(255,sd.getJulDay(),ayandouble); }
*/
hret[40] = sw.swe_get_ayanamsa_ut(sd.getJulDay());

      long hrc=sw.swe_houses(sd.getJulDay(),hflags,hlat,hlong,ihsys,hcusp,hascmc);
	hret[0]=hascmc[0]; 
// -------------------------------------------------- C L O S E    Ayanamsa --------------------------------	
// adding for House cusp
 hret[28]=hcusp[1]; hret[29]=hcusp[2]; hret[30]=hcusp[3];  hret[31]=hcusp[4];
 hret[32]=hcusp[5]; hret[33]=hcusp[6]; hret[34]=hcusp[7];  hret[35]=hcusp[8]; 
 hret[36]=hcusp[9]; hret[37]=hcusp[10];hret[38]=hcusp[11]; hret[39]=hcusp[12];

//System.out.println("Hcsp28K-"+hret[28]+" csp29K-"+hret[29]+" csp39K-"+hret[39]); 

// added for MC      
	hret[25]=hascmc[1];
//
      sw.swe_set_topo(hlong,hlat,0);
     int h1flags = SweConst.SEFLG_SIDEREAL | SweConst.SEFLG_SPEED | SweConst.SEFLG_TOPOCTR;
// TO BE COMPILED; added above 1 line on 28Nov21 - last edit 25 Mar 17 - to set flag topoctr After calling swe set topo
// Also as per Doc, RectAscension(Right Ascension) is East/west, Longitude so speeds to be had in Longitude not Latitude 
// Declinaiton is North/South or Latitude
// ALSO PLS USE Swe_rise_trans() 6.7 in Doc, toCalculate Rising, Setting of Planets by Planet Number

  int iflgret_Sun     = sw.swe_calc_ut(sd.getJulDay(), 0, hflags,hres,sbErr);
		hret[1]=hres[0];hret[2]=hres[1];hret[3]=hres[3];
//System.out.println("Sun-"+hres[0]+"getAy-"+hret[40]);
  int iflgret_Moon    = sw.swe_calc_ut(sd.getJulDay(), 1, h1flags,hres,sbErr);
      if(hres[0]==0.7000000){hret[4]=359.99;}
	  else if(hres[0]<0.700000){hret[4]=hres[0]+360.000-0.700000;}
	  else {hret[4]=hres[0]-0.700000;}
		hret[5]=hres[1];hret[6]=hres[3]; // hret[4]= hres[0];
//System.out.println("Moon-"+hres[0]);
//System.out.println("--Hc1-h1flags= "+h1flags+"  --Hc-moondeg-"+hres[0]);
//array of 6 doubles for 1[0]-longitude, 2[1]-latitude, 3[2]-distance, 4[3]-speed in long., 5-speed in lat., and 6-speed in dist.
//only above comment line added so not compiled, ok
  int iflgret_Mars    = sw.swe_calc_ut(sd.getJulDay(), 4, hflags,hres,sbErr);
		hret[7]=hres[0];hret[8]=hres[2];hret[9]=hres[3];
  int iflgret_Mercury = sw.swe_calc_ut(sd.getJulDay(), 2, hflags,hres,sbErr);
		hret[10]=hres[0];hret[11]=hres[1];hret[12]=hres[3];
  int iflgret_Jupiter = sw.swe_calc_ut(sd.getJulDay(), 5, hflags,hres,sbErr);
		hret[13]=hres[0];hret[14]=hres[2];hret[15]=hres[3];
  int iflgret_Venus   = sw.swe_calc_ut(sd.getJulDay(), 3, hflags,hres,sbErr);
		hret[16]=hres[0];hret[17]=hres[1];hret[18]=hres[3];
  int iflgret_Saturn  = sw.swe_calc_ut(sd.getJulDay(), 6, hflags,hres,sbErr);
		hret[19]=hres[0];hret[20]=hres[2];hret[21]=hres[3];
		// Do not use 11 only 10 is correct BELOW both for P and V
  int iflgret_Rahu    = sw.swe_calc_ut(sd.getJulDay(), 10, hflags,hres,sbErr);
		hret[22]=hres[0];hret[23]=hres[1];hret[24]=hres[3];
// added on 19 Oct
//hret[40] = sw.swe_get_ayanamsa_ut(sd.getJulDay());

	hlong=Double.parseDouble(JLongLat);
	hlat=Double.parseDouble(JLat);

int epheflag = SweConst.SEFLG_SWIEPH;
double[] geopos=new double[3]; 
geopos[0] = 80.27; geopos[1] = 13.08; geopos[2] = 0; 
DblObj trise = new DblObj(); DblObj tset = new DblObj(); 
int return_code1 = sw.swe_rise_trans(sd.getJulDay(), 5,null,epheflag,1,geopos,0,0,trise,sbErr);
int return_code2 = sw.swe_rise_trans(sd.getJulDay(), 5,null,epheflag,2,geopos,0,0,tset, sbErr);
//System.out.println("rise:-"+trise.val+" Set-"+tset.val);


sw.swe_close();

return(hret);
}

public static void  main(String args[])
{  
    Hc2 fjsp = new Hc2();

} //closes main

}
