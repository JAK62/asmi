package DatabaseConnection;
import java.io.*;
import java.sql.*;
public class HospitalConnection
{
	public Connection ConnectMe(){
	Connection conn=null;

		try{
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	 conn=DriverManager.getConnection("jdbc:odbc:hospital","","");
	
		}
		catch(Exception e)
		{System.out.print(e);}
	return conn;
	}

}