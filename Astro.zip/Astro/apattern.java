﻿import java.lang.*; 
import javax.swing.*; 
import java.text.*;
import java.util.*;
import java.io.*;
import java.util.*;
import java.applet.*;
import java.awt.event.*;
import java.awt.*;
import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics; 

public class apattern extends Applet {
    public void paint(Graphics g){
	          Graphics2D g2 = (Graphics2D) g;

	int plps  = Integer.parseInt(getParameter("afps"));
	int plpo  = Integer.parseInt(getParameter("afpo"));
	int plpm  = Integer.parseInt(getParameter("afpm"));
	int plpc  = Integer.parseInt(getParameter("afpc"));
	int plpj  = Integer.parseInt(getParameter("afpj"));
	int plpv  = Integer.parseInt(getParameter("afpv"));
	int plpt  = Integer.parseInt(getParameter("afpt"));
	int plpr  = Integer.parseInt(getParameter("afpr"));
                  int plpk = 0;
	   Color slategray =new Color(112,128,144);
	   Color brown =new Color(205,51,51);
	   Color lg=new Color(220,220,220);

    setBackground(lg); 

 StringBuffer ppss = new StringBuffer("998887877887777899986554457667877887887778877788");
 StringBuffer ppso = new StringBuffer("234465322124454433212421212121123432242121223233");
 StringBuffer ppsm=new StringBuffer("687646654665454445654344566567656565678976544555");
 StringBuffer ppsc= new StringBuffer("123233333455433345445655434334443443343233322113");
 StringBuffer ppsj = new StringBuffer("443334443346897655443322344534346654213443445664");
 StringBuffer ppsv = new StringBuffer("445456654545454456542123456744455675454545457899");
 StringBuffer ppst = new StringBuffer("221123454545454545543233567854433443456756674432");
 StringBuffer ppsr = new StringBuffer("456578976544543232213433455454334443454334212444");
 StringBuffer ppsk = new StringBuffer("454445444544543232213433455457986544454343213543");
 StringBuffer psa = new StringBuffer("00");

	if (plpr==0)  { plpr=1; plpk =181; } 
	else if (plpr>180) {
		plpk=plpr-180;
	           } else  { plpk=plpr+180;
	              } 

                 int[] plpx = {plps,plpo,plpm,plpc,plpj,plpv,plpt,plpr,plpk};
          int mdegahead,mdegbehind=0;
   	     Degp hmdeg = new Degp(plpo,plpr);
		int anydeg[] =hmdeg.howmanydeg();
	     mdegahead=anydeg[0]; mdegbehind=anydeg[1]; 

//    g.drawString("Welcome JSP-Applet",10,10);
    g.drawString("P Pos = "+plps+" "+plpo+" "+plpm+" "+plpc+" "+plpj+" "+plpv+" "+plpt+" "+plpr+" "+plpk, 30, 50);
//        	         g.drawLine(339,10,339,450);//vertical
                        g.setColor(Color.black);
        	         g.drawLine(4,300,800,300);//horizontal
int x=24; int y=1; int n=0;
do {n++;
     g.drawString("|",x,300);
	x=x+7;
     if (n>8){g.drawString("0",x,309); n=0;}

     } while (x<783);
//-------------------------------------------------
x=0; int s=0; int Px=0; int Ps=0;
s=(plps/30);
if (s<5) {x=s+7;}else{x=s-5;}
Ps=(339+((plps%30)*63)/30);

g.setColor(Color.red);
g.drawLine( Ps, 10, (339+((plps%30)*63)/30),450);

g.setColor(Color.cyan);
Px=plpo;
if (plpo > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpo-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );

g.setColor(Color.pink);
Px=plpm;
if (plpm > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpm-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );

g.setColor(Color.green);
Px=plpc;
if (plpc > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpc-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );

g.setColor(Color.yellow);
Px=plpj;
if (plpj > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpj-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );

g.setColor(Color.white);
Px=plpv;
if (plpv > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpv-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );

g.setColor(Color.blue);
Px=plpt;
if (plpt > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpt-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );

g.setColor(Color.black);
Px=plpr;
if (plpr > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpr-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );

g.setColor(brown);
Px=plpk;
if (plpk > (30*x)) {Px=Px-(30*x); }
else  {Px=360+plpk-(30*x); }
g.fillRect( (14+((Px/30)*63)+(((Px%30)*63)/30) ) ,100, 20,200 );
//--------------------------------------------
 
g.setColor(Color.gray);
                       Composite originalComposite = g2.getComposite();
                     g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.9f));
    int x5points[] = {Ps-320,Ps-320,Ps-308,Ps-295,Ps-283};    int y5points[] = {300,150,200,250,300};
g.fillPolygon(x5points,y5points,5);
                     g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.9f));
    int x7points[] = {Ps-217,Ps-190,Ps-162,Ps-132,Ps-102,Ps-72,Ps-42};    int y7points[] = {300,240,190,150,190,240,300};
g.fillPolygon(x7points,y7points,7);
                     g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.6f));
    int x51points[] = {Ps+84,Ps+100,Ps+130,Ps+155,Ps+210};    int y51points[] = {300,220,255,280,300};
g.fillPolygon(x51points,y51points,5);
                     g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.7f));
    int x71points[] = {Ps+301,Ps+316,Ps+331,Ps+346,Ps+361,Ps+376,Ps+392};   
    int y71points[] = {300,260,230,180,230,260,300};
g.fillPolygon(x71points,y71points,7);


g2.setComposite(originalComposite);

//g.draw3DRect(40,40,50,100,true); 		

/*     int i=1; int k=0;
    do {
    g.drawString(dn.substring(i,i*5)+" -- "+ppos[i+k]+" ",100,100*(i+1));
	k = k+3;	i =i+8;
	} while (i <9);    
*/

  }

class Degp
{   int howahead,howbehind,posplan1,posplan2=0;
    Degp(int pos1, int pos2)    { posplan1=pos1; posplan2=pos2;   }
    int[] howmanydeg()    {  
	if (posplan1>posplan2) {
		 if (  (posplan1-posplan2)<180 ) {
		      howbehind= posplan1-posplan2;
                       	      howahead = 0; 
		}  else { 
		          howahead= posplan2+360-posplan1;
                       		howbehind = 0; 
		}
			
                   }  else if (posplan1<posplan2) {
		     if ((posplan2-posplan1)<180) {
		          howahead= posplan2-posplan1;
	                           howbehind = 0; 
		      }  else { 
			howbehind= posplan1+360-posplan2;
                           		howahead = 0;
		     }
	  } 
     int retdeg[]={howahead,howbehind};
     return(retdeg);
      }
} // ends class degp

} 